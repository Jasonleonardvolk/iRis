import { error, json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { writeFile, mkdir } from 'fs/promises';
import { existsSync, readFileSync } from 'fs';
import { join } from 'path';

// 🚀 DYNAMIC API INTEGRATION - Auto-discovers Python API port
interface ApiConfig {
    api_port: number;
    api_url: string;
    timestamp: number;
    status: string;
}

async function getApiUrl(): Promise<string> {
    const configPath = join(process.cwd(), '..', 'api_port.json');
    
    // Try to read dynamic config
    if (existsSync(configPath)) {
        try {
            const configData = readFileSync(configPath, 'utf-8');
            const config: ApiConfig = JSON.parse(configData);
            
            console.log(`🔍 [DYNAMIC] Found API config: ${config.api_url}`);
            return config.api_url;
        } catch (error) {
            console.warn('⚠️ [DYNAMIC] Failed to read API config:', error);
        }
    }
    
    // Fallback to default
    console.log(`🔄 [DYNAMIC] Using fallback: http://localhost:8002`);
    return 'http://localhost:8002';
}

async function callDynamicPythonAPI(buffer: ArrayBuffer, filename: string): Promise<{
    concepts: any[];
    extractionMethod: string;
    success: boolean;
    processingTime: number;
    conceptCount: number;
}> {
    console.log('🚀 [DYNAMIC] Starting dynamic Python API call...');
    console.log(`📁 [DYNAMIC] File: ${filename}, Size: ${buffer.byteLength} bytes`);
    
    const configPath = join(process.cwd(), '..', 'api_port.json');
    
    // Get potential URLs to try
    const urlsToTry: string[] = [];
    
    // First priority: Dynamic config
    if (existsSync(configPath)) {
        try {
            const configData = readFileSync(configPath, 'utf-8');
            const config: ApiConfig = JSON.parse(configData);
            urlsToTry.push(config.api_url);
            console.log(`🎯 [DYNAMIC] Primary URL: ${config.api_url}`);
        } catch (error) {
            console.warn('⚠️ [DYNAMIC] Failed to read API config');
        }
    }
    
    // Add fallback URLs
    const fallbackPorts = [8002, 8003, 8004, 8005];
    for (const port of fallbackPorts) {
        const url = `http://localhost:${port}`;
        if (!urlsToTry.includes(url)) {
            urlsToTry.push(url);
        }
    }
    
    console.log(`🔍 [DYNAMIC] Will try URLs: ${urlsToTry.join(', ')}`);
    
    // Try each URL until one works
    for (let i = 0; i < urlsToTry.length; i++) {
        const baseUrl = urlsToTry[i];
        const extractUrl = `${baseUrl}/extract`;
        
        try {
            console.log(`🚀 [DYNAMIC] Attempt ${i + 1}: ${extractUrl}`);
            
            const formData = new FormData();
            const blob = new Blob([buffer], { type: 'application/pdf' });
            formData.append('file', blob, filename);
            
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 45000); // 45s timeout per attempt
            
            const response = await fetch(extractUrl, {
                method: 'POST',
                body: formData,
                signal: controller.signal,
            });
            
            clearTimeout(timeoutId);
            
            console.log(`📡 [DYNAMIC] Response: ${response.status} ${response.statusText}`);
            
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP ${response.status}: ${errorText}`);
            }
            
            const result = await response.json();
            
            console.log(`✅ [DYNAMIC] SUCCESS on ${extractUrl}`);
            console.log(`📊 [DYNAMIC] Result keys: ${Object.keys(result)}`);
            console.log(`📊 [DYNAMIC] Concept count: ${result.concept_count}`);
            
            return {
                concepts: result.concepts || [],
                extractionMethod: 'enhanced_python_pipeline',
                success: true,
                processingTime: result.processing_time_seconds || 0,
                conceptCount: result.concept_count || 0,
                // Pass through all original data from Python
                ...result,
                usedUrl: baseUrl  // Track which URL worked
            };
            
        } catch (error: any) {
            console.log(`❌ [DYNAMIC] Failed ${extractUrl}: ${error.message}`);
            
            // If this was our last attempt, throw the error
            if (i === urlsToTry.length - 1) {
                throw new Error(`All API URLs failed. Last error: ${error.message}`);
            }
            
            // Otherwise, try the next URL
            continue;
        }
    }
    
    throw new Error('All API attempts failed');
}

// Fallback TypeScript extraction (simplified backup)
async function extractConceptsTypeScriptFallback(text: string): Promise<any[]> {
    console.log('🔄 [FALLBACK] Using TypeScript backup extraction');
    
    const concepts: any[] = [];
    const lowerText = text.toLowerCase();
    
    const domainTerms = [
        'algorithm', 'machine learning', 'artificial intelligence',
        'neural network', 'deep learning', 'learning',
        'computer', 'software', 'programming', 'system',
        'mathematics', 'optimization', 'analysis', 'reinforcement',
        'differential evolution', 'black-box optimization'
    ];
    
    for (const term of domainTerms) {
        if (lowerText.includes(term)) {
            const frequency = (lowerText.match(new RegExp(term, 'g')) || []).length;
            concepts.push({
                name: term.charAt(0).toUpperCase() + term.slice(1),
                score: Math.min(0.8, 0.5 + frequency * 0.1),
                method: 'typescript_fallback',
                source: { fallback: true, frequency: frequency }
            });
        }
    }
    
    console.log(`🔄 [FALLBACK] Found: ${concepts.length} concepts`);
    return concepts.slice(0, 20);
}

// 🧬 MAIN EXTRACTION FUNCTION - Dynamic API with fallback
async function extractConceptsEnhanced(buffer: ArrayBuffer, filename: string): Promise<{
    concepts: any[];
    extractionMethod: string;
    success: boolean;
    processingTime: number;
    conceptCount: number;
}> {
    console.log('🧬 [ENHANCED] DYNAMIC EXTRACTION - Auto-Discovery Approach');
    const startTime = Date.now();
    
    try {
        // Step 1: Try Dynamic Python API
        console.log('🚀 [ENHANCED] STEP 1: Dynamic Python API...');
        const apiResult = await callDynamicPythonAPI(buffer, filename);
        
        // 🔧 FIXED: Check for concept_names instead of concepts
        if (apiResult.success && apiResult.concept_names?.length > 0) {
            console.log('✅ [ENHANCED] Python API SUCCESS - Using Python results');
            console.log(`🧬 [ENHANCED] Found ${apiResult.concept_names.length} concept names from Python`);
            
            // 🎯 SURGICAL FIX: Map concept_names to full concept objects
            apiResult.concepts = apiResult.concept_names.map((name: string, i: number) => ({
                name,
                score: Math.max(0.4, 0.9 - i * 0.03), // Descending scores
                method: 'enhanced_python_pipeline',
                source: {
                    python_extraction: true,
                    enhanced_pipeline: true,
                    original_rank: i + 1
                },
                context: `Python-extracted concept: ${name}`,
                metadata: {
                    rank: i + 1,
                    from: 'pipeline.py',
                    extraction_method: 'enhanced_python_pipeline',
                    processing_time: apiResult.processing_time_seconds,
                    used_url: apiResult.usedUrl,
                    original_concept_count: apiResult.concept_count
                }
            }));
            
            // Update concept count to match the mapped concepts
            apiResult.conceptCount = apiResult.concepts.length;
            
            console.log('🎉 [ENHANCED] Python pipeline SUCCESS - Mapped concept_names to objects');
            console.log(`📊 [ENHANCED] Final concept count: ${apiResult.concepts.length}`);
            
            return apiResult;
        } else {
            console.log('⚠️ [ENHANCED] Python API returned no concept_names, using fallback');
            console.log(`🔍 [ENHANCED] API result keys: ${Object.keys(apiResult)}`);
        }
        
    } catch (apiError: any) {
        console.log('🔄 [ENHANCED] Dynamic Python API failed, using TypeScript fallback:', apiError.message);
    }
    
    // Step 2: TypeScript fallback
    console.log('🔄 [ENHANCED] STEP 2: TypeScript fallback...');
    
    try {
        const textContent = new TextDecoder('utf-8', { fatal: false }).decode(buffer);
        console.log(`📄 [ENHANCED] Decoded text length: ${textContent.length} characters`);
        
        const concepts = await extractConceptsTypeScriptFallback(textContent);
        
        const processingTime = (Date.now() - startTime) / 1000;
        
        console.log(`✅ [ENHANCED] TypeScript fallback complete: ${concepts.length} concepts in ${processingTime}s`);
        
        return {
            concepts: concepts,
            extractionMethod: 'typescript_fallback',
            success: true,
            processingTime: processingTime,
            conceptCount: concepts.length
        };
        
    } catch (fallbackError) {
        console.error('❌ [ENHANCED] Both Dynamic API and TypeScript fallback failed:', fallbackError);
        return {
            concepts: [],
            extractionMethod: 'extraction_failed',
            success: false,
            processingTime: (Date.now() - startTime) / 1000,
            conceptCount: 0
        };
    }
}

// Trigger ELFIN++ onUpload hook
function triggerELFINUpload(filename: string, concepts: any[]) {
    try {
        console.log('🧬 [ELFIN] onUpload triggered:', {
            filename,
            conceptCount: concepts.length
        });
        return true;
    } catch (err) {
        console.warn('[ELFIN] hook failed:', err);
        return false;
    }
}

export const POST: RequestHandler = async ({ request, locals }) => {
    console.log('📥 [UPLOAD] Dynamic upload request received');
    
    // 🛡️ Security: Check admin role
    if (!locals.user || locals.user.role !== 'admin') {
        console.log('❌ [UPLOAD] Access denied - admin role required');
        throw error(403, 'Admin access required for document uploads');
    }
    
    console.log(`👤 [UPLOAD] User authorized: ${locals.user.name}`);
    
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        
        if (!file) {
            console.log('❌ [UPLOAD] No file in request');
            throw error(400, 'No file uploaded');
        }
        
        console.log(`📁 [UPLOAD] File received: ${file.name} (${file.size} bytes, ${file.type})`);
        
        // 🛡️ Security: Validate file type and size
        const maxSize = 50 * 1024 * 1024; // 50MB limit
        if (file.size > maxSize) {
            console.log(`❌ [UPLOAD] File too large: ${file.size} bytes > ${maxSize} bytes`);
            throw error(400, 'File too large (max 50MB)');
        }
        
        const allowedTypes = ['application/pdf', 'text/plain'];
        if (!allowedTypes.includes(file.type) && !file.name.toLowerCase().endsWith('.pdf')) {
            console.log(`❌ [UPLOAD] Invalid file type: ${file.type}`);
            throw error(400, 'Unsupported file type. PDF and TXT files only.');
        }
        
        // 🛡️ Security: Sanitize filename
        const sanitizedFilename = file.name.replace(/[^a-zA-Z0-9.-]/g, '_').substring(0, 100);
        const timestamp = Date.now();
        const uniqueFilename = `${timestamp}_${sanitizedFilename}`;
        
        console.log(`📋 [UPLOAD] Sanitized filename: ${uniqueFilename}`);
        
        // Create storage directory
        const uploadDir = join(process.cwd(), 'data', 'sphere', 'admin');
        if (!existsSync(uploadDir)) {
            console.log(`📁 [UPLOAD] Creating upload directory: ${uploadDir}`);
            await mkdir(uploadDir, { recursive: true });
        }
        
        // Save file to disk
        const filePath = join(uploadDir, uniqueFilename);
        const arrayBuffer = await file.arrayBuffer();
        await writeFile(filePath, new Uint8Array(arrayBuffer));
        
        console.log(`💾 [UPLOAD] File saved to: ${filePath}`);
        
        console.log('🧬 [UPLOAD] STARTING DYNAMIC EXTRACTION');
        
        // 🧬 DYNAMIC API-BASED CONCEPT EXTRACTION
        const extractionResult = await extractConceptsEnhanced(arrayBuffer, file.name);
        
        console.log(`🎯 [UPLOAD] EXTRACTION COMPLETE: ${extractionResult.conceptCount} concepts found`);
        console.log(`🧠 [UPLOAD] Method: ${extractionResult.extractionMethod}`);
        
        // Trigger ELFIN++ processing
        const elfinTriggered = triggerELFINUpload(file.name, extractionResult.concepts);
        
        // Prepare response data
        const documentData = {
            id: `doc_${timestamp}`,
            filename: file.name,
            uniqueFilename,
            size: file.size,
            type: file.type,
            concepts: extractionResult.concepts,
            uploadedAt: new Date().toISOString(),
            uploadedBy: locals.user.name,
            filePath,
            elfinTriggered,
            summary: `Dynamic extraction found ${extractionResult.conceptCount} concepts using ${extractionResult.extractionMethod}`,
            extractionMethod: extractionResult.extractionMethod,
            dynamicExtraction: true,
            processingTime: extractionResult.processingTime,
            conceptCount: extractionResult.conceptCount,
            pythonApiUsed: extractionResult.extractionMethod.includes('python')
        };
        
        // Log successful upload
        console.log('📚 [UPLOAD] DYNAMIC UPLOAD COMPLETE:', {
            filename: file.name,
            size: file.size,
            concepts: extractionResult.conceptCount,
            method: extractionResult.extractionMethod,
            processingTime: extractionResult.processingTime,
            apiUsed: extractionResult.extractionMethod.includes('python'),
            elfinTriggered
        });
        
        return json({
            success: true,
            message: `Document uploaded and processed with dynamic extraction (${extractionResult.extractionMethod})`,
            document: documentData
        });
        
    } catch (err) {
        console.error('🧬 [UPLOAD] Dynamic upload failed:', err);
        
        if (err instanceof Error && err.message.includes('Admin access required')) {
            throw err;
        }
        
        throw error(500, 'Upload processing failed: ' + (err instanceof Error ? err.message : 'Unknown error'));
    }
};

write_file({
  path: 'C:\\Users\\jason\\Desktop\\tori\\kha\\tori_ui_svelte\\src\\lib\\cognitive\\cognitiveEngine_phase3.ts',
  content: `// Enhanced CognitiveEngine with Phase 3 Memory Metrics & Paradox Analysis
import { 
  cognitiveState, 
  updateCognitiveState, 
  LoopRecord, 
  incrementLoopDepth, 
  decrementLoopDepth,
  CognitiveThresholds,
  addScar,
  healScar
} from './cognitiveState';
import { contradictionMonitor } from './contradictionMonitor';
import { phaseController } from './phaseController';
import { closureGuard, ClosureResult, FeedbackOptions } from './closureGuard';
import { braidMemory } from './braidMemory';
import { NoveltyGlyph } from './loopRecord';
import { memoryMetrics, MemoryHealth } from './memoryMetrics';
import { paradoxAnalyzer, AssociatorResult } from './paradoxAnalyzer';
import { get } from 'svelte/store';

export interface CognitiveEngineConfig {
  enablePhaseGating: boolean;
  enableContradictionMonitoring: boolean;
  enableClosureGuard: boolean;
  enableBraidMemory: boolean;
  enableMemoryMetrics: boolean;
  enableParadoxAnalysis: boolean;
  autoStabilization: boolean;
  autoNoveltyInjection: boolean;
  autoReflectiveLoops: boolean;
  debugMode: boolean;
}

export class CognitiveEngine {
  private config: CognitiveEngineConfig;
  private isInitialized: boolean = false;
  private loopCounter: number = 0;
  private activeLoops: Map<string, LoopRecord> = new Map();
  private reflectiveLoops: Map<string, string> = new Map(); // paradoxId -> loopId
  private eventListeners: Map<string, Array<(...args: any[]) => void>> = new Map();
  private recursiveBurstMonitor: {
    contextNorm: number;
    compressionGain: number;
    gammaThreshold: number;
    burstRisk: boolean;
  } = {
    contextNorm: 0,
    compressionGain: 1,
    gammaThreshold: 2.5, // N2M-RSI threshold
    burstRisk: false
  };

  constructor(config: Partial<CognitiveEngineConfig> = {}) {
    this.config = {
      enablePhaseGating: true,
      enableContradictionMonitoring: true,
      enableClosureGuard: true,
      enableBraidMemory: true,
      enableMemoryMetrics: true,
      enableParadoxAnalysis: true,
      autoStabilization: true,
      autoNoveltyInjection: true,
      autoReflectiveLoops: true,
      debugMode: false,
      ...config
    };
    
    console.log('🧠 CognitiveEngine Phase 3 initializing with metacognitive awareness:', this.config);
  }

  /**
   * Initialize the cognitive engine and all subsystems
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      console.warn('🧠 CognitiveEngine already initialized');
      return;
    }

    console.log('🧠 Starting cognitive engine Phase 3 initialization...');

    // Initialize Phase 1 subsystems
    if (this.config.enablePhaseGating) {
      console.log('🌊 Phase gating enabled');
    }

    if (this.config.enableContradictionMonitoring) {
      console.log('🔍 Contradiction monitoring enabled');
    }

    if (this.config.enableClosureGuard) {
      console.log('🛡️ Closure guard enabled');
    }

    // Initialize Phase 2 subsystems
    if (this.config.enableBraidMemory) {
      console.log('🧬 Braid memory enabled');
      this.setupBraidMemoryIntegration();
    }

    // Initialize Phase 3 subsystems
    if (this.config.enableMemoryMetrics) {
      console.log('📊 Memory metrics enabled');
      this.setupMemoryMetricsIntegration();
    }

    if (this.config.enableParadoxAnalysis) {
      console.log('🔺 Paradox analysis enabled');
      this.setupParadoxAnalysisIntegration();
    }

    // Set up event listeners
    this.setupEventListeners();

    // Set up periodic maintenance
    this.setupPeriodicMaintenance();

    this.isInitialized = true;
    console.log('✅ CognitiveEngine Phase 3 initialization complete');

    // Emit initialization event
    this.emit('initialized', { config: this.config, phase: 3 });
  }

  /**
   * Set up memory metrics integration
   */
  private setupMemoryMetricsIntegration(): void {
    // Listen for metric updates
    memoryMetrics.onUpdate((metrics, health) => {
      this.handleMemoryMetricsUpdate(metrics, health);
    });
    
    // Listen for memory alerts
    if (typeof window !== 'undefined') {
      window.addEventListener('tori:memory-alert', (event: any) => {
        this.handleMemoryAlert(event.detail);
      });
      
      window.addEventListener('tori:memory-consolidate', (event: any) => {
        this.handleMemoryConsolidation(event.detail);
      });
    }
    
    console.log('📊 Memory metrics integration configured');
  }

  /**
   * Set up paradox analysis integration
   */
  private setupParadoxAnalysisIntegration(): void {
    // Listen for paradox events
    paradoxAnalyzer.onParadox((event) => {
      this.handleParadoxDetected(event);
    });
    
    // Listen for reflective loop spawn requests
    if (typeof window !== 'undefined') {
      window.addEventListener('tori:spawn-reflective-loop', (event: any) => {
        this.spawnReflectiveLoop(event.detail);
      });
    }
    
    console.log('🔺 Paradox analysis integration configured');
  }

  /**
   * Handle memory metrics update
   */
  private handleMemoryMetricsUpdate(metrics: any, health: MemoryHealth): void {
    // Update recursive burst monitor
    this.updateRecursiveBurstMonitor(metrics);
    
    // Handle health-based actions
    switch (health) {
      case MemoryHealth.CRITICAL:
      case MemoryHealth.UNSTABLE:
        this.handleUnstableMemory(health, metrics);
        break;
        
      case MemoryHealth.UNDERLEARNING:
        this.handleUnderlearning(metrics);
        break;
    }
    
    // Update cognitive state with memory health
    updateCognitiveState({
      // Add memory health to cognitive state
      memoryHealth: health as any,
      memoryDensity: metrics.rhoM,
      memoryCurvature: metrics.kappaI
    } as any);
  }

  /**
   * Update recursive burst monitor (N2M-RSI detection)
   */
  private updateRecursiveBurstMonitor(metrics: any): void {
    const state = get(cognitiveState);
    
    // Calculate context norm growth
    const newContextNorm = Math.sqrt(
      metrics.memoryArea * state.loopDepth * (1 + state.contradictionPi)
    );
    
    // Calculate compression gain
    const stats = braidMemory.getStats();
    const newCompressionGain = stats.compressionRatio > 0 ? 
      1 / stats.compressionRatio : 1;
    
    // Check for burst condition
    const burstRisk = newContextNorm > this.recursiveBurstMonitor.gammaThreshold &&
                     state.volatilitySigma < 0.1; // Low volatility + high context = risk
    
    this.recursiveBurstMonitor = {
      contextNorm: newContextNorm,
      compressionGain: newCompressionGain,
      gammaThreshold: this.recursiveBurstMonitor.gammaThreshold,
      burstRisk
    };
    
    if (burstRisk && !this.recursiveBurstMonitor.burstRisk) {
      console.warn('⚠️ N2M-RSI burst risk detected! Context norm:', newContextNorm.toFixed(2));
      this.enterReflectiveLockdown();
    }
  }

  /**
   * Enter reflective lockdown to prevent recursive burst
   */
  private enterReflectiveLockdown(): void {
    console.log('🔒 Entering reflective lockdown');
    
    // Slow down phase progression
    phaseController.setFrequency(phaseController.getFrequency() * 0.5);
    
    // Inject stabilization glyph
    const activeLoopId = get(cognitiveState).activeLoopId;
    if (activeLoopId) {
      this.addGlyph(activeLoopId, 'phase-drift'); // Phase desynchronization
    }
    
    // Emit lockdown event
    this.emit('reflective-lockdown', {
      reason: 'N2M-RSI burst prevention',
      contextNorm: this.recursiveBurstMonitor.contextNorm
    });
    
    // Schedule recovery
    setTimeout(() => {
      phaseController.setFrequency(phaseController.getFrequency() * 2); // Restore
      console.log('🔓 Exiting reflective lockdown');
    }, 10000); // 10 second lockdown
  }

  /**
   * Handle unstable memory conditions
   */
  private handleUnstableMemory(health: MemoryHealth, metrics: any): void {
    console.warn(\`⚠️ Memory health \${health}: ρ_M=\${metrics.rhoM.toFixed(3)}, κ_I=\${metrics.kappaI.toFixed(3)}\`);
    
    // If Gödelian collapse risk, take immediate action
    if (metrics.godelianCollapseRisk) {
      this.handleGodelianCollapseRisk();
    }
    
    // Trigger memory consolidation
    if (metrics.scarRatio > 0.5) {
      this.triggerScarHealing();
    }
    
    // Reduce processing intensity
    if (health === MemoryHealth.CRITICAL) {
      this.emit('critical-memory-state', { metrics });
    }
  }

  /**
   * Handle Gödelian collapse risk
   */
  private handleGodelianCollapseRisk(): void {
    console.error('🌀 Gödelian collapse risk detected! Initiating emergency protocols');
    
    // Flag all active loops
    for (const [loopId, loop] of this.activeLoops) {
      if (!loop.metadata) loop.metadata = {};
      loop.metadata.godelianCollapseDetected = true;
    }
    
    // Inject memory anchor glyph
    const activeLoopId = get(cognitiveState).activeLoopId;
    if (activeLoopId) {
      this.addGlyph(activeLoopId, 'memory-anchor');
    }
    
    // Request persona swap to break pattern
    this.emit('persona-swap-suggested', {
      from: get(cognitiveState).activePersona,
      to: 'Explorer', // Explorer is good at finding new paths
      reason: 'Gödelian collapse prevention'
    });
  }

  /**
   * Handle underlearning condition
   */
  private handleUnderlearning(metrics: any): void {
    if (this.config.debugMode) {
      console.log(\`📊 Underlearning detected: ρ_M=\${metrics.rhoM.toFixed(3)}\`);
    }
    
    // Could trigger learning enhancement routines
    this.emit('underlearning-detected', { metrics });
  }

  /**
   * Handle memory alert
   */
  private handleMemoryAlert(alert: any): void {
    console.log(\`📊 Memory alert: \${alert.type}\`, alert.data);
    
    switch (alert.type) {
      case 'curvature-spike':
        // High curvature indicates paradox accumulation
        this.checkForParadoxes();
        break;
        
      case 'density-drop':
        // Density drop might indicate memory loss
        this.emit('memory-density-drop', alert.data);
        break;
        
      case 'godelian-collapse-risk':
        this.handleGodelianCollapseRisk();
        break;
    }
  }

  /**
   * Handle memory consolidation request
   */
  private handleMemoryConsolidation(data: any): void {
    console.log('📊 Memory consolidation requested:', data.reason);
    
    // Trigger scar healing
    this.triggerScarHealing();
    
    // Compress old loops more aggressively
    // This would be implemented in braidMemory
    this.emit('memory-consolidation', data);
  }

  /**
   * Check for paradoxes in recent operations
   */
  private checkForParadoxes(): void {
    if (!this.config.enableParadoxAnalysis) return;
    
    // Get recent glyphs from active loops
    const recentOps: string[] = [];
    for (const [_, loop] of this.activeLoops) {
      if (loop.glyphPath.length >= 3) {
        recentOps.push(...loop.glyphPath.slice(-3));
      }
    }
    
    if (recentOps.length >= 3) {
      // Check associator bracket for last 3 operations
      const result = paradoxAnalyzer.measureAssociator(
        recentOps[0],
        recentOps[1], 
        recentOps[2]
      );
      
      if (result.type === 'cyclic' || result.type === 'chaotic') {
        console.warn(\`🔺 Paradox in recent operations: \${result.type}\`);
      }
    }
  }

  /**
   * Handle paradox detection
   */
  private handleParadoxDetected(event: any): void {
    console.log(\`🔺 Paradox detected: \${event.associatorResult.type} (\${event.associatorResult.value.toFixed(3)})\`);
    
    // Auto-spawn reflective loop if configured
    if (this.config.autoReflectiveLoops && 
        (event.associatorResult.type === 'cyclic' || event.associatorResult.type === 'chaotic')) {
      paradoxAnalyzer.spawnReflectiveLoop(event.id);
    }
    
    // Update contradiction based on paradox severity
    const contradictionDelta = event.associatorResult.value * 0.5;
    contradictionMonitor.updateContradiction(contradictionDelta);
    
    // Emit for UI visualization
    this.emit('paradox-detected', event);
  }

  /**
   * Spawn reflective loop for paradox resolution
   */
  private async spawnReflectiveLoop(data: any): Promise<void> {
    const { paradoxId, prompt, type, paradoxClass } = data;
    
    console.log(\`🔄 Spawning reflective loop for paradox \${paradoxId}\`);
    
    // Create reflective loop with special metadata
    const loopId = await this.startLoop(\`REFLECT: \${prompt}\`, {
      isReflective: true,
      reflectDepth: 1,
      paradoxId,
      paradoxType: type,
      paradoxClass
    });
    
    // Track reflective loop
    this.reflectiveLoops.set(paradoxId, loopId);
    
    // Add initial glyphs based on paradox type
    if (paradoxClass === 'godel') {
      await this.addGlyph(loopId, 'inverse(X)');
      await this.addGlyph(loopId, 'stabilize');
    } else if (paradoxClass === 'condorcet') {
      await this.addGlyph(loopId, 'reorder');
      await this.addGlyph(loopId, 'phase-align');
    } else {
      await this.addGlyph(loopId, 'paradox-embrace');
      await this.addGlyph(loopId, 'coherence-boost');
    }
    
    // Attempt closure with special handling
    setTimeout(async () => {
      const result = await this.closeLoop(loopId, 'paradox-resolved');
      if (result.allowed) {
        paradoxAnalyzer.resolveParadox(paradoxId, loopId);
      }
    }, 5000); // Give 5 seconds for reflection
  }

  /**
   * Trigger scar healing process
   */
  private triggerScarHealing(): void {
    console.log('🩹 Triggering scar healing process');
    
    const stats = braidMemory.getStats();
    if (stats.scarredLoops === 0) return;
    
    // Get unresolved paradoxes
    const unresolvedParadoxes = paradoxAnalyzer.getUnresolvedParadoxes();
    
    // Attempt to heal scars by resolving paradoxes
    unresolvedParadoxes.slice(0, 3).forEach(paradox => {
      if (this.config.autoReflectiveLoops) {
        paradoxAnalyzer.spawnReflectiveLoop(paradox.id);
      }
    });
    
    // Heal scar in cognitive state
    healScar();
    
    this.emit('scar-healing-initiated', {
      scarCount: stats.scarredLoops,
      paradoxCount: unresolvedParadoxes.length
    });
  }

  /**
   * Enhanced loop starting with paradox checking
   */
  async startLoop(prompt: string, metadata?: Record<string, any>): Promise<string> {
    // Check for recursive reflection
    if (metadata?.isReflective && prompt.startsWith('REFLECT:REFLECT:')) {
      console.warn('🔒 Blocking recursive reflection');
      throw new Error('Recursive reflection depth exceeded');
    }
    
    const loopId = \`loop_\${++this.loopCounter}_\${Date.now()}\`;
    
    const loop: LoopRecord = {
      id: loopId,
      prompt,
      glyphPath: [],
      phaseTrace: [],
      coherenceTrace: [],
      contradictionTrace: [],
      closed: false,
      scarFlag: false,
      timestamp: new Date(),
      processingTime: 0,
      metadata: {
        ...metadata,
        phaseGateHits: [],
        reflectDepth: metadata?.reflectDepth || 0
      }
    };

    this.activeLoops.set(loopId, loop);
    incrementLoopDepth();

    // Update cognitive state
    updateCognitiveState({
      activeLoopId: loopId
    });

    console.log(\`🔄 Started cognitive loop: \${loopId} ("\${prompt.substring(0, 50)}...")\`);
    this.emit('loop-started', { loopId, prompt, metadata });

    return loopId;
  }

  // ... [Include all the existing Phase 2 methods here] ...

  /**
   * Enhanced diagnostics with Phase 3 metrics
   */
  getDiagnostics(): {
    isInitialized: boolean;
    config: CognitiveEngineConfig;
    activeLoops: number;
    reflectiveLoops: number;
    cognitiveState: any;
    contradictionStatus: any;
    phaseStatus: any;
    closureStats: any;
    braidMemoryStats?: any;
    memoryMetrics?: any;
    paradoxStats?: any;
    recursiveBurstMonitor?: any;
  } {
    const baseDiagnostics = {
      isInitialized: this.isInitialized,
      config: this.config,
      activeLoops: this.activeLoops.size,
      reflectiveLoops: this.reflectiveLoops.size,
      cognitiveState: get(cognitiveState),
      contradictionStatus: contradictionMonitor.getDiagnostics(),
      phaseStatus: phaseController.getDiagnostics(),
      closureStats: closureGuard.getDiagnostics()
    };

    // Add Phase 2 stats
    if (this.config.enableBraidMemory) {
      baseDiagnostics.braidMemoryStats = braidMemory.getStats();
    }

    // Add Phase 3 stats
    if (this.config.enableMemoryMetrics) {
      baseDiagnostics.memoryMetrics = {
        current: memoryMetrics.getMetrics(),
        health: memoryMetrics.getHealth(),
        trend: memoryMetrics.getTrend()
      };
    }

    if (this.config.enableParadoxAnalysis) {
      baseDiagnostics.paradoxStats = paradoxAnalyzer.getStats();
    }

    baseDiagnostics.recursiveBurstMonitor = this.recursiveBurstMonitor;

    return baseDiagnostics;
  }

  // ... [Include remaining methods from original cognitiveEngine.ts] ...
}

// Enhanced singleton instance for global access
export const cognitiveEngine = new CognitiveEngine({
  enableBraidMemory: true,
  enableMemoryMetrics: true,
  enableParadoxAnalysis: true,
  autoNoveltyInjection: true,
  autoReflectiveLoops: true
});

// Auto-initialize in browser environment
if (typeof window !== 'undefined') {
  cognitiveEngine.initialize().catch(error => {
    console.error('Failed to initialize Phase 3 cognitive engine:', error);
  });
}

console.log('🧠 CognitiveEngine Phase 3 system ready with metacognitive awareness');`
})